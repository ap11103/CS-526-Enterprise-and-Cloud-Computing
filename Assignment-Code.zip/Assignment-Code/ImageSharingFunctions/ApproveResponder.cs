using System;
using Azure.Storage.Queues.Models;
using ImageSharingModels;
using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;

namespace ImageSharingFunctions
{
    /*
     * This function responds to approval of an image, by inserting metadata for the image into the database.
     */

    // https://learn.microsoft.com/en-us/azure/azure-functions/functions-bindings-cosmosdb-v2?tabs=isolated-process%2Cextensionv4&pivots=programming-language-csharp

    public class ApproveResponder
    {
        private const string CosmosDbConnectionString = "CosmosDbConnectionString";

        private const string DatabaseName = "imagesharing";

        private const string ContainerName = "images";
        
        private readonly ILogger<ApproveResponder> _logger;

        private readonly Container _container;


        public ApproveResponder(ILogger<ApproveResponder> logger,
                                CosmosClient client)
        {
            _logger = logger;
            var database = client.GetDatabase(DatabaseName);
            _container = database.GetContainer(ContainerName);
        }

        public static CosmosClient GetImageDbClient()
        {
            var connectionString = Environment.GetEnvironmentVariable(CosmosDbConnectionString);
            var client = new CosmosClient(connectionString);
            return client;
        }

        // TODO
        // Annotate for trigger (use approved-images queue trigger)
        [Function(nameof(ApproveResponder))]
        public async Task Run(QueueMessage message)
        {
            var imageJson = ImageProperties.MessageTextToString(message.MessageText);
            _logger.LogInformation("Processing approval of image:\n{imageJson}", imageJson);

            _logger.LogInformation("Saving image metadata to CosmosDB database.");
            Image? image = null;
            // TODO deserialize the image object from the message queue, set Approved, and add it to the database

        }
    }
}
