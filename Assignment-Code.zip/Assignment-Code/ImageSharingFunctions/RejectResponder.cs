using Azure.Storage.Blobs;
using Azure.Storage.Queues.Models;
using ImageSharingModels;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;

namespace ImageSharingFunctions
{
    /*
     * This function responds to rejection of an image, by deleting it from blob storage.
     */


    public class RejectResponder
    {
        private readonly ILogger<RejectResponder> _logger;

        private const string BlobStorageConnectionString = "BlobStorageConnectionString";

        private const string BlobContainer = "images";

        public RejectResponder(ILogger<RejectResponder> logger)
        {
            _logger = logger;
        }

        // TODO A
        // nnotate for trigger (use rejected-images queue, no output but blob client used to delete image)
        [Function(nameof(RejectResponder))]
        public async Task Run(QueueMessage message)
        {
            _logger.LogInformation($"Rejected approval of image: {message.MessageText}");

            Image? image = null;
            // TODO deserialize the image object from the message queue.

            var connectionString = Environment.GetEnvironmentVariable(BlobStorageConnectionString);
            if (connectionString == null)
            {
                throw new ArgumentNullException($"Missing connection string in environment: \"{BlobStorageConnectionString}\"");
            }

            var blobServiceClient = new BlobServiceClient(connectionString);

            var blobContainerClient = blobServiceClient.GetBlobContainerClient(BlobContainer);

            await blobContainerClient.DeleteBlobAsync(image.GetBlobId());
        }
    }
}
