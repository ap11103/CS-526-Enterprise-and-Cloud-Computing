﻿using System.Text;
using Newtonsoft.Json;

namespace ImageSharingModels
{
    /*
     * Properties provided as metadata when an image is uploaded.
     */
    public static class ImageProperties
    {
        public const string UrlKey = "url";

        public const string UserKey = "user";

        public const string IdKey = "id";

        public const string UsernameKey = "username";

        public const string CaptionKey = "caption";

        public const string DescriptionKey = "description";

        public const string DateTakenKey = "dateTaken";


        /*
         * Helper functions
         */
        public static Image MessageTextToImage(string messageText)
        {
            // Image object is JSON string in message payload
            return JsonConvert.DeserializeObject<Image>(MessageTextToString(messageText));
        }

        public static string MessageTextToString(string messageText)
        {
            return Encoding.UTF8.GetString(MessageTextToBytes(messageText));
        }

        public static byte[] MessageTextToBytes(string messageText)
        {
            // Message payload is base64-encoded by Azure Queue.
            return Convert.FromBase64String(messageText);
        }

        public static string ImageToMessageText(Image image)
        {
            var json = JsonConvert.SerializeObject(image);
            var data = Encoding.UTF8.GetBytes(json);
            return Convert.ToBase64String(data);
        }

    }
}
