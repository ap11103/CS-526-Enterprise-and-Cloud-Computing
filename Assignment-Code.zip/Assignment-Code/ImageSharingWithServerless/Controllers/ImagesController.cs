﻿using ImageSharingModels;
using ImageSharingWithServerless.DAL;
using ImageSharingWithServerless.Models;
using ImageSharingWithServerless.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using static ImageSharingWithServerless.DAL.IImageStorage;

namespace ImageSharingWithServerless.Controllers
{
    // TODO require authorization by default
    public class ImagesController : BaseController
    {
        private readonly ILogContext _logContext;

        private readonly ILogger<ImagesController> _logger;

        // Dependency injection
        public ImagesController(UserManager<ApplicationUser> userManager,
                                ApplicationDbContext userContext,
                                ILogContext logContext,
                                IImageStorage imageStorage,
                                ILogger<ImagesController> logger)
            : base(userManager, imageStorage, userContext)
        {
            this._logContext = logContext;

            this._logger = logger;
        }


        // TODO

        public ActionResult Upload()
        {
            CheckAda();

            ViewBag.Message = "";
            var imageView = new ImageView();
            return View(imageView);
        }

        // TODO
        // Prevent CSRF

        public async Task<ActionResult> Upload(ImageView imageView)
        {
            CheckAda();

            _logger.LogDebug("Processing the upload of an image....");

            await TryUpdateModelAsync(imageView);

            if (!ModelState.IsValid)
            {
                ViewBag.Message = "Please correct the errors in the form!";
                return View();
            }

            _logger.LogDebug("...getting the current logged-in user....");
            var user = await GetLoggedInUser();

            if (imageView.ImageFile == null || imageView.ImageFile.Length <= 0)
            {
                ViewBag.Message = "No image file specified!";
                return View(imageView);
            }

            var imageId = Guid.NewGuid().ToString();

            /*
             * We will attach metadata for image to upload to blob storage.
             * Once upload is finished, image metadata will be saved in Cosmos DB.
             */
            IDictionary<string, string> metadata = new Dictionary<string, string>();
            metadata[ImageProperties.UserKey] = user.Id;
            metadata[ImageProperties.IdKey] = imageId;
            metadata[ImageProperties.UsernameKey] = user.UserName;
            metadata[ImageProperties.CaptionKey] = imageView.Caption;
            metadata[ImageProperties.DescriptionKey] = imageView.Description;
            DateTime dateTakenUtc = DateTime.SpecifyKind(imageView.DateTaken, DateTimeKind.Utc);
            metadata[ImageProperties.DateTakenKey] = JsonConvert.SerializeObject(dateTakenUtc);
            metadata[ImageProperties.UrlKey] = ImageStorage.ImageUri(user.Id, imageId);

            _logger.LogDebug("...saving image file to blob storage....");

            // TODO
            // Save image file on disk
            // 1. Be sure to include metadata, which will be processed by Azure function
            // 2. No need to await finish of upload! (catch and log exceptions on upload thread)
            // Because this call is not awaited, execution of the current method continues before the call is completed
            #pragma warning disable CS4014

            #pragma warning restore CS4014 

            ViewBag.Message = "Image uploaded!";
            return View(new ImageView());
        }

        // TODO
        // [HttpGet]
        // [Authorize(Roles = "User")]
        // public ActionResult Query()
        // {
        //     CheckAda();
        //
        //     ViewBag.Message = "";
        //     return View();
        // }

        // TODO

        public async Task<ActionResult> Details(string UserId, string Id)
        {
            CheckAda();

            var image = await ImageStorage.GetImageInfoAsync(UserId, Id);
            if (image == null)
            {
                return RedirectToAction("Error", "Home", new { ErrId = "Details: " + Id });
            }

            var imageView = new ImageView()
            {
                Id = image.Id,
                Caption = image.Caption,
                Description = image.Description,
                DateTaken = image.DateTaken,
                Uri = ImageStorage.ImageUri(image.UserId, image.Id),

                UserName = image.UserName,
                UserId = image.UserId
            };

            var thisUser = await GetLoggedInUser();
            // TODO
            // Log this view of the image asynchronously
            // Because this call is not awaited, execution of the current method continues before the call is completed
            #pragma warning disable CS4014
            
            #pragma warning restore CS4014 

            return View(imageView);
        }

        // TODO

        public async Task<ActionResult> Edit(string UserId, string Id)
        {
            CheckAda();
            var user = await GetLoggedInUser();
            if (user == null || !user.Id.Equals(UserId))
            {
                return RedirectToAction("Error", "Home", new { ErrId = "EditNotAuth" });
            }

            var image = await ImageStorage.GetImageInfoAsync(UserId, Id);
            if (image == null)
            {
                return RedirectToAction("Error", "Home", new { ErrId = "EditNotFound" });
            }

            ViewBag.Message = "";

            var imageView = new ImageView()
            {
                Id = image.Id,
                Caption = image.Caption,
                Description = image.Description,
                DateTaken = image.DateTaken,

                UserId = image.UserId,
                UserName = image.UserName
            };

            return View("Edit", imageView);
        }

        // TODO
        // Prevent CSRF

        public async Task<ActionResult> DoEdit(string UserId, string Id, ImageView imageView)
        {
            CheckAda();

            if (!ModelState.IsValid)
            {
                ViewBag.Message = "Please correct the errors on the page";
                imageView.Id = Id;
                return View("Edit", imageView);
            }

            var user = await GetLoggedInUser();
            if (user == null || !user.Id.Equals(UserId))
            {
                return RedirectToAction("Error", "Home", new { ErrId = "EditNotAuth" });
            }

            _logger.LogDebug("Saving changes to image " + Id);
            var image = await ImageStorage.GetImageInfoAsync(imageView.UserId, Id);
            if (image == null)
            {
                return RedirectToAction("Error", "Home", new { ErrId = "EditNotFound" });
            }

            image.Caption = imageView.Caption;
            image.Description = imageView.Description;
            image.DateTaken = imageView.DateTaken;
            await ImageStorage.UpdateImageInfoAsync(image);

            return RedirectToAction("Details", new { UserId = UserId, Id = Id });
        }

        // TODO

        public async Task<ActionResult> Delete(string UserId, string Id)
        {
            CheckAda();
            var user = await GetLoggedInUser();
            if (user == null || !user.Id.Equals(UserId))
            {
                return RedirectToAction("Error", "Home", new { ErrId = "EditNotAuth" });
            }

            var image = await ImageStorage.GetImageInfoAsync(user.Id, Id);
            if (image == null)
            {
                return RedirectToAction("Error", "Home", new { ErrId = "EditNotFound" });
            }

            ImageView imageView = new ImageView()
            {
                Id = image.Id,
                Caption = image.Caption,
                Description = image.Description,
                DateTaken = image.DateTaken,
                UserName = image.UserName
            };
            return View(imageView);
        }

        // TODO
        // Prevent CSRF

        public async Task<ActionResult> DoDelete(string UserId, string Id)
        {
            CheckAda();
            var user = await GetLoggedInUser();
            if (user == null || !user.Id.Equals(UserId))
            {
                return RedirectToAction("Error", "Home", new { ErrId = "EditNotAuth" });
            }

            var image = await ImageStorage.GetImageInfoAsync(user.Id, Id);
            if (image == null)
            {
                return RedirectToAction("Error", "Home", new { ErrId = "EditNotFound" });
            }

            await ImageStorage.RemoveImageAsync(image);

            return RedirectToAction("Index", "Home");

        }

        // TODO

        public async Task<ActionResult> ListAll()
        {
            CheckAda();
            var user = await GetLoggedInUser();

            var images = await ImageStorage.GetAllImagesInfoAsync();
            ViewBag.UserId = user.Id;
            return View(images);
        }

        // TODO

        public async Task<IActionResult> ListByUser()
        {
            CheckAda();

            // Return form for selecting a user from a drop-down list
            var userView = new ListByUserModel();
            var defaultId = (await GetLoggedInUser()).Id;

            userView.Users = new SelectList(ActiveUsers(), "Id", "UserName", defaultId);
            return View(userView);
        }

        // TODO

        public async Task<ActionResult> DoListByUser(ListByUserModel userView)
        {
            CheckAda();

            var user = await GetLoggedInUser();
            ViewBag.UserId = user.Id;

            var theUser = await UserManager.FindByIdAsync(userView.Id);
            if (theUser == null)
            {
                return RedirectToAction("Error", "Home", new { ErrId = "ListByUser" });
            }

            // TODO
            // List all images uploaded by the user in userView
            /*
             * Eager loading of related entities
             */

            return null;
            // End TODO

        }

        // TODO

        public ActionResult ImageViews()
        {
            CheckAda();
            return View();
        }

        // TODO

        public ActionResult ImageViewsList(string Today)
        {
            CheckAda();
            _logger.LogDebug("Looking up log views, \"Today\"=" + Today);
            var entries = _logContext.Logs("true".Equals(Today));
            _logger.LogDebug("Query completed, rendering results....");
            return View(entries);
        }


        /*
         * Image Approval actions.
         */

        [HttpGet]
        [Authorize(Roles = "Approver")]
        public async Task<IActionResult> Approve()
        {
            CheckAda();

            _logger.LogDebug("Retrieving approval requests....");
            var pendingApprovals = await ImageStorage.AwaitingApprovalAsync();
            var items = new List<SelectListItem>();
            foreach (var pendingApproval in pendingApprovals)
            {
                var uri = pendingApproval.Image.Uri;
                var json = JsonConvert.SerializeObject(pendingApproval);
                var item = new SelectListItem { Text = uri, Value = json, Selected = false };
                items.Add(item);
            }

            ViewBag.message = "";
            var model = new ApproveModel { Images = items };
            return View(model);
        }

        [HttpPost]
        [Authorize(Roles = "Approver")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Approve(ApproveModel model)
        {
            CheckAda();

            foreach (var item in model.Images)
            {
                var pending = JsonConvert.DeserializeObject<PendingApproval>(item.Value);
                if (item.Selected)
                {
                    await ImageStorage.ApproveAsync(pending);
                }
                else
                {
                    await ImageStorage.RejectAsync(pending);
                }
            }

            ViewBag.message = "Images approved!";

            return View(new ApproveModel { Images = new List<SelectListItem>() }); ;
        }

    }

}
