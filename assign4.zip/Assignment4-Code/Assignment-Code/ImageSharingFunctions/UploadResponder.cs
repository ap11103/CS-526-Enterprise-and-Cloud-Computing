using ImageSharingModels;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace ImageSharingFunctions
{
    /*
     * This function responds to completion of upload of an image, by requesting approval of the image.
     * In a production setting, it might first do some form of validation of the image such as parsing
     * it as an image, with the approval request sent after that validation succeeded.
     */

    // https://learn.microsoft.com/en-us/azure/azure-functions/dotnet-isolated-process-guide

    // https://learn.microsoft.com/en-us/azure/azure-functions/functions-develop-vs?tabs=in-process

    // https://learn.microsoft.com/en-us/azure/storage/blobs/blob-upload-function-trigger?tabs=in-process

    // https://learn.microsoft.com/en-us/azure/azure-functions/functions-bindings-storage-queue-output?tabs=isolated-process%2Cextensionv5&pivots=programming-language-csharp

    public class UploadResponder
    {
        private readonly ILogger<UploadResponder> _logger;

        public UploadResponder(ILogger<UploadResponder> logger)
        {
            _logger = logger;
        }

        // TODO
        // Annotate for trigger and for queue output
        [Function(nameof(UploadResponder))]
        [QueueOutput(ApprovalRequestsQueueName, Connection = StorageConnectionString)]
        public string Run([BlobTrigger(BlobContainerName + "/{blobname}", Connection = StorageConnectionString)] string myBlob,
            string blobname,
            IDictionary<string, string> metadata)
        {
            var image = new Image
            {
                UserId = metadata[ImageProperties.UserKey],
                Id = metadata[ImageProperties.IdKey],
                UserName = metadata[ImageProperties.UsernameKey],
                Caption = metadata[ImageProperties.CaptionKey],
                Description = metadata[ImageProperties.DescriptionKey],
                DateTaken = JsonConvert.DeserializeObject<DateTime>(metadata[ImageProperties.DateTakenKey]),
                Uri = metadata[ImageProperties.UrlKey],
                Valid = true, // Should really be validated by a microservice
                Approved = false // Requires oversight for approval
            };

            // Azure Queue requires that message payload is Base64-encoded.
            var messageText = ImageProperties.ImageToMessageText(image);

            _logger.LogInformation("Image uploaded ({blobname}), requesting approval.\nImage: {imageUri}", blobname, image.Uri);

            return messageText;
        }
    }
}
