﻿using Azure;
using Azure.Storage;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Azure.Storage.Queues;
using Azure.Storage.Queues.Models;
using ImageSharingModels;
using ImageSharingWithServerless.Models;
using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Cosmos.Linq;
using Microsoft.EntityFrameworkCore;
using static ImageSharingWithServerless.DAL.IImageStorage;

namespace ImageSharingWithServerless.DAL
{
    public class ImageStorage : IImageStorage
    {
        private readonly ILogger<ImageStorage> _logger;

        private readonly CosmosClient _imageDbClient;

        private readonly string _imageDatabase;

        private readonly Container _imageDbContainer;

        private readonly BlobContainerClient _blobContainerClient;


        public ImageStorage(IConfiguration configuration,
                            CosmosClient imageDbClient,
                            ILogger<ImageStorage> logger)
        {
            this._logger = logger;

            /*
             * Use Cosmos DB client to store metadata for images.
             */
            this._imageDbClient = imageDbClient;

            this._imageDatabase = configuration[StorageConfig.ImageDbDatabase];

            this._imageDbContainer = GetImageDbContainer(configuration);

            /*
             * Use Blob storage client to store images in the cloud.
             */
            this._blobContainerClient = GetBlobContainerClient(configuration);
            logger.LogInformation("ImageStorage (Blob storage) being accessed here: " + _blobContainerClient.Uri);

            /*
             * Use queues for asynchronous triggers of serverless functions.
             */
            this._approvalRequestsQueueName = configuration[StorageConfig.ApprovalRequestsQueue];
            this._approvedImagesQueueName = configuration[StorageConfig.ApprovedImagesQueue];
            this._rejectedImagesQueueName = configuration[StorageConfig.RejectedImagesQueue];

            // TODO
            // Set the queue clients for approval requests, approved and rejected images (use createQueueClient).
            // You should log the queue URIs here to ensure this has succeeded.

            this._maxApprovalRequests = configuration.GetValue<int>(StorageConfig.MaxApprovalRequests);
            this._visibilityTimeout = TimeSpan.FromSeconds(configuration.GetValue<int>(StorageConfig.VisibilityTimeout));
        }

        /**
         * Use this to generate the singleton Cosmos DB client that is injected into all instances of ImageStorage.
         */
        public static CosmosClient GetImageDbClient(IWebHostEnvironment environment, IConfiguration configuration)
        {
            var imageDbUri = configuration[StorageConfig.ImageDbUri];
            if (imageDbUri == null)
            {
                throw new ArgumentNullException("Missing configuration: " + StorageConfig.ImageDbUri);
            }
            var imageDbAccessKey = configuration[StorageConfig.ImageDbAccessKey];

            CosmosClientOptions cosmosClientOptions = null;
            //if (environment.IsDevelopment())
            //{
            //    cosmosClientOptions = new CosmosClientOptions()
            //    {
            //        HttpClientFactory = () =>
            //        {
            //            HttpMessageHandler httpMessageHandler = new HttpClientHandler()
            //            {
            //                ServerCertificateCustomValidationCallback = HttpClientHandler.DangerousAcceptAnyServerCertificateValidator
            //            };

            //            return new HttpClient(httpMessageHandler);
            //        },
            //        ConnectionMode = ConnectionMode.Gateway
            //    };
            //}

            var imageDbClient = new CosmosClient(imageDbUri, imageDbAccessKey, cosmosClientOptions);
            return imageDbClient;
        }

        /**
         * Use this to generate the Cosmos DB container client
         */
        private Container GetImageDbContainer(IConfiguration configuration)
        {
            var imageContainer = configuration[StorageConfig.ImageDbContainer];
            _logger.LogDebug("ImageDb (Cosmos DB) is being accessed here: " + _imageDbClient.Endpoint);
            _logger.LogDebug("ImageDb using database {0} and container {1}",
                _imageDatabase, imageContainer);
            var imageDbDatabase = _imageDbClient.GetDatabase(_imageDatabase);
            return imageDbDatabase.GetContainer(imageContainer);
        }

        /**
         * Use this to generate the blob container client
         */
        private static BlobContainerClient GetBlobContainerClient(IConfiguration configuration)
        {
            var imageStorageUriFromConfig = configuration[StorageConfig.ImageStorageUri];
            if (imageStorageUriFromConfig == null)
            {
                throw new KeyNotFoundException("Missing Blob service URI in configuration: " + StorageConfig.ImageStorageUri);
            }
            var imageStorageUri = new Uri(imageStorageUriFromConfig);

            StorageSharedKeyCredential credential = null;
            // TODO get the shared key credential for accessing blob storage.
            var imageStorageAccountName = configuration[StorageConfig.ImageStorageAccountName];
            var imageStorageAccountKey = configuration[StorageConfig.ImageStorageAccessKey];
            credential = new StorageSharedKeyCredential(imageStorageAccountName, imageStorageAccountKey);

            var blobServiceClient = new BlobServiceClient(imageStorageUri, credential, null);

            var storageContainer = configuration[StorageConfig.ImageStorageContainer];
            if (storageContainer == null)
            {
                throw new KeyNotFoundException("Missing Blob container name in configuration: " + StorageConfig.ImageStorageContainer);
            }
            return blobServiceClient.GetBlobContainerClient(storageContainer);

        }


        /*
         * Initialize image database and queues.
         */
        public async Task InitImageStorage()
        {
            _logger.LogInformation("Initializing image storage (Cosmos DB and Blob Storage)....");
            await _imageDbClient.CreateDatabaseIfNotExistsAsync(_imageDatabase);
            await _blobContainerClient.CreateIfNotExistsAsync();
            var images = await GetAllImagesInfoAsync();
            foreach (var image in images)
            {
                await RemoveImageAsync(image);
            }
            _logger.LogInformation("....initialization completed.");


            var queueResponse = await _approvalRequests.CreateIfNotExistsAsync();
            if (queueResponse != null)
            {
                _logger.LogInformation("Confirmed approval request queue: {0}", this._approvalRequestsQueueName);
            }

            queueResponse = await _approvedImages.CreateIfNotExistsAsync();
            if (queueResponse != null)
            {
                _logger.LogInformation("Confirmed approved requests queue: {0}", this._approvedImagesQueueName);
            }

            queueResponse = await _rejectedImages.CreateIfNotExistsAsync();
            if (queueResponse != null)
            {
                _logger.LogInformation("Confirmed rejected requests queue: {0}", this._rejectedImagesQueueName);
            }

            await _approvalRequests.ClearMessagesAsync();
            await _approvedImages.ClearMessagesAsync();
            await _rejectedImages.ClearMessagesAsync();
        }


        public async Task<Image> GetImageInfoAsync(string userId, string imageId)
        {
            return await _imageDbContainer.ReadItemAsync<Image>(imageId, new PartitionKey(userId));
        }

        public async Task<IList<Image>> GetAllImagesInfoAsync()
        {
            var results = new List<Image>();
            var iterator = _imageDbContainer.GetItemLinqQueryable<Image>()
                                           .Where(im => im.Valid && im.Approved)
                                           .ToFeedIterator();
            // Iterate over the paged query result.
            while (iterator.HasMoreResults)
            {
                var images = await iterator.ReadNextAsync();
                // Iterate over a page in the query result.
                foreach (var image in images)
                {
                    results.Add(image);
                }
            }
            return results;
        }

        public async Task<IList<Image>> GetImageInfoByUserAsync(ApplicationUser user)
        {
            var results = new List<Image>();
            var query = _imageDbContainer.GetItemLinqQueryable<Image>()
                                        .WithPartitionKey<Image>(user.Id)
                                        .Where(im => im.Valid && im.Approved);
            // TODO complete this
            var iterator = query.ToFeedIterator();
            while (iterator.HasMoreResults)
            {
                var images = await iterator.ReadNextAsync();
                foreach (var image in images)
                {
                    results.Add(image);
                }
            }
            return results;
        }

        public async Task UpdateImageInfoAsync(Image image)
        {
            await _imageDbContainer.ReplaceItemAsync<Image>(image, image.Id, new PartitionKey(image.UserId));
        }

        /*
         * Remove both image files and their metadata records in the database.
         */
        public async Task RemoveImagesAsync(ApplicationUser user)
        {
            var query = _imageDbContainer.GetItemLinqQueryable<Image>().WithPartitionKey<Image>(user.Id);
            var iterator = query.ToFeedIterator();
            while (iterator.HasMoreResults)
            {
                var images = await iterator.ReadNextAsync();
                foreach (Image image in images)
                {
                    await RemoveImageAsync(image);
                }
            }
            /*
             * Not available?
             * await imageDbContainer.DeleteAllItemsByPartitionKeyStreamAsync(new PartitionKey(image.UserId))
             */
        }

        public async Task RemoveImageAsync(Image image)
        {
            try
            {
                await RemoveImageFileAsync(image);
            }
            catch (RequestFailedException e)
            {
                _logger.LogError("Exception while removing blob image: ", e.StackTrace);
            }
            await _imageDbContainer.DeleteItemAsync<Image>(image.Id, new PartitionKey(image.UserId));
        }


        /**
         * The name of a blob containing a saved image (imageId is key for metadata record).
         */
        private static string BlobName(string userId, string imageId)
        {
            return imageId;
        }

        private string BlobUri(string userId, string imageId)
        {
            return _blobContainerClient.Uri + "/" + BlobName(userId, imageId);
        }

        public Task SaveImageFileAsync(IFormFile imageFile, string userId, string imageId, IDictionary<string, string> metadata)
        {
            _logger.LogInformation("Saving image with id {0} to blob storage", imageId);

            var headers = new BlobHttpHeaders()
            {
                ContentType = "image/jpeg"
            };

            /*
             * TODO upload data to blob storage
             * 
             * Tip: You need to reset the stream position to the beginning before uploading:
             * See https://stackoverflow.com/a/47611795.
             * 
             * Do NOT await the finishing of the upload!
             */

            return Task.CompletedTask;

        }

        private async Task RemoveImageFileAsync(Image image)
        {
            var blobClient = _blobContainerClient.GetBlobClient(BlobName(image.UserId, image.Id));
            _logger.LogInformation("Deleting image blob at URI {0}", blobClient.Uri);
            await blobClient.DeleteAsync();
        }

        public string ImageUri(string userId, string imageId)
        {
            return BlobUri(userId, imageId);
        }

        private bool IsOkImage(Image image)
        {
            return image.Valid && image.Approved;
        }

        /*
         * API for image approval.
         */

        // https://learn.microsoft.com/en-us/azure/storage/queues/storage-dotnet-how-to-use-queues?tabs=dotnet

        // https://learn.microsoft.com/en-us/dotnet/api/azure.storage.queues.queueclient?view=azure-dotnet


        private readonly string _approvalRequestsQueueName;

        private readonly string _approvedImagesQueueName;

        private readonly string _rejectedImagesQueueName;

        private readonly QueueClient _approvalRequests;

        private readonly QueueClient _approvedImages;

        private readonly QueueClient _rejectedImages;

        /*
         * Maximum number of requests to be processed in one go (should be in app settings)
         */
        private readonly int _maxApprovalRequests;

        /*
         * How long approval request messages are invisible while they are being processed (should be in app settings)
         */
        private readonly TimeSpan _visibilityTimeout;

        private static QueueClient CreateQueueClient(Uri queueUri, string queueName, string accountName, string accessKey)
        {
            /*
             * Queue when reading messages expects Base64 encoding for payload, but does not
             * automatically encode with Base64 when sending, so set it here as default behavior.
             */
            var connectionString = $"DefaultEndpointsProtocol=http;AccountName={accountName};AccountKey={accessKey};QueueEndpoint={queueUri}";
            var client = new QueueClient(connectionString, queueName, new QueueClientOptions
            {
                MessageEncoding = QueueMessageEncoding.Base64
            });
            return client;
        }

        /*
         * Get a list of images awaiting approval (from the approval-requests queue).
         */
        public async Task<IEnumerable<PendingApproval>> AwaitingApprovalAsync()
        {
            QueueMessage[] messages = await _approvalRequests.ReceiveMessagesAsync(_maxApprovalRequests, _visibilityTimeout);
            _logger.LogDebug($"Getting list of approval requests from message queue ({messages.Length} messages)....");
            var pending = new List<PendingApproval>();
            foreach (QueueMessage message in messages)
            {
                var image = ImageProperties.MessageTextToImage(message.MessageText);
                _logger.LogDebug($"...approval request: {image.Uri}...");
                var pendingApproval = new PendingApproval()
                {
                    Image = image,
                    MessageId = message.MessageId,
                    MessagePopReceipt = message.PopReceipt
                };
                pending.Add(pendingApproval);
            }
            return pending;
        }

        /*
         * An image is approved: remove it from the approval-requests queue and add it to the approved-images queue.
         */
        public async Task ApproveAsync(PendingApproval pending)
        {
            _logger.LogDebug($"Image has been approved: {pending.Image.Uri}");
            var messageText = ImageProperties.ImageToMessageText(pending.Image);
            await _approvedImages.SendMessageAsync(messageText);
            await _approvalRequests.DeleteMessageAsync(pending.MessageId, pending.MessagePopReceipt);
        }

        /*
         * An image is rejected: remove it from the approval-requests queue and add it to the rejected-images queue.
         */
        public async Task RejectAsync(PendingApproval pending)
        {
            _logger.LogDebug($"Image has been rejected: {pending.Image.Uri}");
            // TODO
            // Remove from requests queue and add to rejects queue

        }


    }
}
