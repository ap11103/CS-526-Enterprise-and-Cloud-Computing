﻿using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using ImageSharingWithServerless.Models;
using ImageSharingModels;

namespace ImageSharingWithServerless.DAL
{
    public  class ApplicationDbInitializer
    {
        private readonly ApplicationDbContext _db;
        private readonly IImageStorage _imageStorage;
        private readonly ILogContext _logContext;
        private readonly ILogger<ApplicationDbInitializer> _logger;
        public ApplicationDbInitializer(ApplicationDbContext db, 
                                        IImageStorage imageStorage,
                                        ILogContext logContext,
                                        ILogger<ApplicationDbInitializer> logger)
        {
            this._db = db;
            this._imageStorage = imageStorage;   
            this._logContext = logContext;
            this._logger = logger;
        }

        public async Task SeedDatabase(IServiceProvider serviceProvider)
        {
            /*
             * Initialize databases.
             */
            _logger.LogInformation("Initializing databases and blob storage....");
            await _imageStorage.InitImageStorage();

            _logger.LogInformation("Clearing out the user database....");
            await _db.Database.MigrateAsync();
            _db.RemoveRange(_db.Users);
            await _db.SaveChangesAsync();

            _logger.LogDebug("Adding role: User");
            var idResult = await CreateRole(serviceProvider, "User");
            if (!idResult.Succeeded)
            {
                _logger.LogDebug("Failed to create User role!");
            }

            // TODO
            // Add other roles


            _logger.LogDebug("Adding user: jfk");
            idResult = await CreateAccount(serviceProvider, "jfk@example.org", "jfk123", "Admin");
            if (!idResult.Succeeded)
            {
                _logger.LogDebug("Failed to create jfk user!");
            }

            _logger.LogDebug("Adding user: nixon");
            idResult = await CreateAccount(serviceProvider, "nixon@example.org", "nixon123", "User");
            if (!idResult.Succeeded)
            {
                _logger.LogDebug("Failed to create nixon user!");
            }

            // TODO
            // Add other users and assign more roles

            await _db.SaveChangesAsync();

        }

        private static async Task<IdentityResult> CreateRole(IServiceProvider provider,
                                                             string role)
        {
            RoleManager<IdentityRole> roleManager = provider
                .GetRequiredService
                       <RoleManager<IdentityRole>>();
            var idResult = IdentityResult.Success;
            if (await roleManager.FindByNameAsync(role) == null)
            {
                idResult = await roleManager.CreateAsync(new IdentityRole(role));
            }
            return idResult;
        }

        private static async Task<IdentityResult> CreateAccount(IServiceProvider provider,
                                                               string email, 
                                                               string password,
                                                               string role)
        {
            UserManager<ApplicationUser> userManager = provider
                .GetRequiredService
                       <UserManager<ApplicationUser>>();
            var idResult = IdentityResult.Success;

            if (await userManager.FindByNameAsync(email) == null)
            {
                ApplicationUser user = new ApplicationUser { UserName = email, Email = email };
                idResult = await userManager.CreateAsync(user, password);

                if (idResult.Succeeded)
                {
                    idResult = await userManager.AddToRoleAsync(user, role);
                }
            }

            return idResult;
        }

    }
}